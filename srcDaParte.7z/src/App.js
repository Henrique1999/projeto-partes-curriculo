import './App.css';
import ArquivoProjeto from './Arquivos/arquivoProjeto.js';


/* 
Para rodar o projeto: "npm start", talvez precise de "cd my-app" (ambos comandos sem aspas)
precisa ter o node.js instalado e o npm instalado. caso não tenha baixe nesse link: https://nodejs.org/en/
*/
function App() {
return (
<>
<ArquivoProjeto />
</>
);
}

export default App;
